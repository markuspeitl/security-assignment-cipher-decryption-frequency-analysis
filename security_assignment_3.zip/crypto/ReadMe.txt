#will install package default-jre and run security_cipher_breaker.jar
#with the path arguments /home/security/crypto/cipher and /home/security/crypto/secret
#run following line in this directory and with terminal
#if java runtime is already installed that part can be skipped with "n"

bash decrypt_secret.sh

# source code to security_cipher_breaker.jar is located in security_cipher_breaker/src/sample/
# in Main.java and CipherManager.java