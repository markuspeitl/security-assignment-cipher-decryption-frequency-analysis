#Install Java Runtime -> press "n" if already installed
sudo apt install default-jre
#Run cipher breaker java binary with cipher and secret path as arguments
java -jar security_cipher_breaker.jar /home/security/crypto/cipher /home/security/crypto/secret